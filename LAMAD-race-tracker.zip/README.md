# LAMAD-race-tracker
Javascript web application for race tracking
